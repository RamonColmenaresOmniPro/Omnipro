<?php
namespace Omnipro\OmniBlog\Ui\DataProvider\Posts;

class GridDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
}
