<?php
Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Omnipro_OmniBlog',
    __DIR__
);
